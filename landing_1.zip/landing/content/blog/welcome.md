---
title: "Welcome to our amazing blog."
shortDescription: "Know a little more about WittyLytics"
watermark: "Blog"
date: 2020-01-10T09:51:57+06:00
description : "wittylytics welcome post"
bgImage: "images/background/about.jpg"
image : "images/blog/blog-post-1.jpg"
author : "Editor"
type : "post"
categories: 
  - "Marketing"
tags:
  - "Welcome"
  - "Company"
---

### Welcome to WittyLytics

We are very excited to announce the entrance of our company in the IT market.

Stay tunned for more soon!.